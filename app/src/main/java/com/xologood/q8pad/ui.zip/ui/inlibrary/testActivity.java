package com.xologood.q8pad.ui.inlibrary;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.xologood.q8pad.R;

public class testActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);
    }
}
